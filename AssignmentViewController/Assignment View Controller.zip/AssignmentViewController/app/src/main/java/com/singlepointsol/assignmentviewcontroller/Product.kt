package com.singlepointsol.assignmentviewcontroller

data class Product(val name: String, val price: Double)
